# Archived/inactive-link leaderboard privacy withdrawal

Base: `15a1e305a359d858a16205d6ba87773629eb8c4f`.
`manifest.json` pins exactly six release paths and `repair.patch`; `source/`
contains their reviewed after bytes, with before bytes for four existing paths.
Do not copy diagnostic/browser contexts into the checkout.

False withdrawal now uses the existing download/delete privacy token contract,
independent of a wheel or active play link. The service-only helper in privacy.ts
updates only `fans.leaderboard_opt_in:false`, filtered by both token-derived fan
ID and creator ID. Unknown/malformed/deleted credentials and read/write/transport
errors fail closed. Any caller-supplied handle is ignored on false. Joining still
uses its prior real active-pass/wheel authorization; demo now also rejects true
joining after self-exclusion. No economic, link, wheel, handle or history state is
changed by withdrawal. Existing shared privacy resolution also rejects a read
that carries an error, even if its transport returns data alongside that error.

The branded 404 still returns 404. Its existing explicitly opened rescue panel
now includes the same withdrawal-only control beside Download/Delete. The
existing toggle label is byte-identical for current browser assertions, and a
fixed visible hint makes the additional action discoverable. No server fan data,
public ranking read, auto POST, join/rename or reactivation is added. Malformed
path percent-encoding no longer throws inside this rescue component.

Actual isolated validation:

- New real/mock data and negative-authorization tests:63 checks pass.
- New actual rescue/shared-control lifecycle tests:19 checks pass.
- Existing withdrawal72, engagement35, recovery38 and history28 tests pass with
  their original source bytes unchanged.
- Existing privacy94, privacy mock21, leaderboard privacy20 and opt-in route45
  checks pass.
- Whole TypeScript and focused ESLint pass. Initial test-only TypeScript
  narrowing diagnostics are retained separately; final source is clean.
- Five causal controls fail as expected: old wheel-gated withdrawal, missing
  creator scope, ignored token-read error, paused mock rejoin and missing rescue
  withdrawal control.
- Installed Next16 usePathname documentation was read before modification.

No live checkout changes, hosted calls, SQL/schema changes, new routes or new
dependencies were made here. This is not a full release receipt. Root must apply
these six paths, commit the final combined source and restart both complete local
verification rounds before pushing. Hosted CI/TEST/Preview gates remain separate.
A bounded real-demo browser proof is being collected in a separate disposable
copy after source freeze; its receipt must be read independently and is not
claimed by this frozen manifest.
