#!/usr/bin/env bash
set -euo pipefail

FANFUNNEL_TOOLS=/workspace/.tools
FANFUNNEL_REPO=/workspace/fanfunnel
FANFUNNEL_NODE_VERSION=v22.23.4
FANFUNNEL_NODE_ARCHIVE="node-${FANFUNNEL_NODE_VERSION}-linux-x64.tar.xz"
FANFUNNEL_NODE_ROOT="${FANFUNNEL_TOOLS}/node-${FANFUNNEL_NODE_VERSION}-linux-x64"
FANFUNNEL_NODE_SHA256=1805bcd35e6815559bd2eb97db438d3fdb0eb3a5e6a977b7c1badca76337e9ce
FANFUNNEL_TEST_TOOLS="${FANFUNNEL_TOOLS}/fanfunnel-test-tools"

if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  printf 'This tested Node installation targets Linux x86_64.\n' >&2
  exit 1
fi
test -f "${FANFUNNEL_REPO}/package-lock.json"
mkdir -p "$FANFUNNEL_TOOLS" /workspace/.cache/npm /workspace/.cache/ms-playwright

if [[ ! -x "${FANFUNNEL_NODE_ROOT}/bin/node" ]]; then
  if [[ -e "$FANFUNNEL_NODE_ROOT" ]]; then
    printf 'Existing Node directory is incomplete; inspect it before replacement: %s\n' "$FANFUNNEL_NODE_ROOT" >&2
    exit 1
  fi
  FANFUNNEL_NODE_DOWNLOAD=$(mktemp -d "${FANFUNNEL_TOOLS}/node22-install.XXXXXX")
  trap 'rm -rf "$FANFUNNEL_NODE_DOWNLOAD"' EXIT
  (
    cd "$FANFUNNEL_NODE_DOWNLOAD"
    curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' \
      "https://nodejs.org/dist/${FANFUNNEL_NODE_VERSION}/SHASUMS256.txt" --output SHASUMS256.txt
    curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' \
      "https://nodejs.org/dist/${FANFUNNEL_NODE_VERSION}/${FANFUNNEL_NODE_ARCHIVE}" --output "$FANFUNNEL_NODE_ARCHIVE"
    awk -v archive="$FANFUNNEL_NODE_ARCHIVE" \
      '$2 == archive { print; count++ } END { if (count != 1) exit 1 }' \
      SHASUMS256.txt > selected-sha256.txt
    sha256sum --check selected-sha256.txt
    printf '%s  %s\n' "$FANFUNNEL_NODE_SHA256" "$FANFUNNEL_NODE_ARCHIVE" > pinned-sha256.txt
    sha256sum --check pinned-sha256.txt
    tar --extract --xz --file "$FANFUNNEL_NODE_ARCHIVE" --directory "$FANFUNNEL_TOOLS"
  )
  rm -rf "$FANFUNNEL_NODE_DOWNLOAD"
  trap - EXIT
fi
test "$("${FANFUNNEL_NODE_ROOT}/bin/node" --version)" = "$FANFUNNEL_NODE_VERSION"

cat > "${FANFUNNEL_TOOLS}/fanfunnel-postgres-install.sh" <<'FANFUNNEL_POSTGRES_INSTALLER'
#!/usr/bin/env bash
set -euo pipefail

# PostgreSQL is a build dependency, kept outside the application checkout.
# Source: official PostgreSQL GitHub mirror, release REL_16_15.
FANFUNNEL_PG_VERSION=16.15
FANFUNNEL_PG_COMMIT=7d3e000c5961a544302072058a1184e9a588837b
FANFUNNEL_PG_ROOT=/workspace/.tools/postgresql-16
FANFUNNEL_PG_SOURCE=/workspace/.tools/postgresql-16-source
FANFUNNEL_PG_BUILD=/workspace/.tools/postgresql-16-build
FANFUNNEL_PG_DEPS=/workspace/.tools/postgresql-build-deps
FANFUNNEL_PG_APT="${FANFUNNEL_PG_DEPS}/apt"

FANFUNNEL_PG_COMPLETE=1
for FANFUNNEL_PG_PROGRAM in postgres initdb pg_ctl pg_config psql pg_dump pg_restore createdb dropdb; do
  if [[ ! -x "${FANFUNNEL_PG_ROOT}/bin/${FANFUNNEL_PG_PROGRAM}" ]]; then
    FANFUNNEL_PG_COMPLETE=0
  fi
done
if [[ "$FANFUNNEL_PG_COMPLETE" == 1 ]] && \
  [[ "$("${FANFUNNEL_PG_ROOT}/bin/pg_config" --version)" == "PostgreSQL ${FANFUNNEL_PG_VERSION}" ]] && \
  [[ -f "${FANFUNNEL_PG_ROOT}/share/extension/pgcrypto.control" ]]; then
  "${FANFUNNEL_PG_ROOT}/bin/postgres" --version
  "${FANFUNNEL_PG_ROOT}/bin/psql" --version
  "${FANFUNNEL_PG_ROOT}/bin/pg_dump" --version
  exit 0
fi

for FANFUNNEL_PG_PREREQUISITE in cc make perl git curl pkg-config apt-get dpkg-deb; do
  command -v "$FANFUNNEL_PG_PREREQUISITE" >/dev/null
done
test -r /usr/share/keyrings/debian-archive-keyring.pgp
pkg-config --exists zlib openssl
mkdir -p "$FANFUNNEL_PG_BUILD" "$FANFUNNEL_PG_DEPS"

if [[ ! -x "${FANFUNNEL_PG_DEPS}/root/usr/bin/bison" || \
      ! -x "${FANFUNNEL_PG_DEPS}/root/usr/bin/flex" || \
      ! -x "${FANFUNNEL_PG_DEPS}/root/usr/bin/m4" ]]; then
  mkdir -p "${FANFUNNEL_PG_APT}/lists/partial" \
    "${FANFUNNEL_PG_APT}/cache/archives/partial" \
    "${FANFUNNEL_PG_APT}/log" "${FANFUNNEL_PG_APT}/apt.conf.d" \
    "${FANFUNNEL_PG_DEPS}/packages" "${FANFUNNEL_PG_DEPS}/root"
  touch "${FANFUNNEL_PG_APT}/empty.conf"
  cat > "${FANFUNNEL_PG_APT}/sources.list" <<'FANFUNNEL_PG_SOURCES'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.pgp] https://deb.debian.org/debian trixie main
FANFUNNEL_PG_SOURCES
  cat > "${FANFUNNEL_PG_APT}/apt.conf" <<'FANFUNNEL_PG_APT_CONFIG'
Dir::Etc::main "/workspace/.tools/postgresql-build-deps/apt/empty.conf";
Dir::Etc::parts "/workspace/.tools/postgresql-build-deps/apt/apt.conf.d";
Dir::Etc::sourcelist "/workspace/.tools/postgresql-build-deps/apt/sources.list";
Dir::Etc::sourceparts "/workspace/.tools/postgresql-build-deps/apt/apt.conf.d";
Dir::State "/workspace/.tools/postgresql-build-deps/apt";
Dir::State::lists "/workspace/.tools/postgresql-build-deps/apt/lists";
Dir::State::status "/var/lib/dpkg/status";
Dir::Cache "/workspace/.tools/postgresql-build-deps/apt/cache";
Dir::Log "/workspace/.tools/postgresql-build-deps/apt/log";
Acquire::https::Proxy "http://proxy:8080";
Acquire::Languages "none";
FANFUNNEL_PG_APT_CONFIG
  # apt validates InRelease signatures with the image's Debian archive keyring
  # and validates package hashes from that authenticated package index.
  APT_CONFIG="${FANFUNNEL_PG_APT}/apt.conf" apt-get update
  (
    cd "${FANFUNNEL_PG_DEPS}/packages"
    APT_CONFIG="${FANFUNNEL_PG_APT}/apt.conf" apt-get download bison flex m4
    for FANFUNNEL_PG_PACKAGE in ./*.deb; do
      dpkg-deb --extract "$FANFUNNEL_PG_PACKAGE" "${FANFUNNEL_PG_DEPS}/root"
    done
  )
fi
export PATH="${FANFUNNEL_PG_DEPS}/root/usr/bin:$PATH"
export BISON_PKGDATADIR="${FANFUNNEL_PG_DEPS}/root/usr/share/bison"
export M4="${FANFUNNEL_PG_DEPS}/root/usr/bin/m4"
bison --version | head -n 1
flex --version
m4 --version | head -n 1

if [[ ! -e "$FANFUNNEL_PG_SOURCE" ]]; then
  git clone --depth 1 --branch REL_16_15 --single-branch \
    https://github.com/postgres/postgres.git "$FANFUNNEL_PG_SOURCE"
fi
test "$(git -C "$FANFUNNEL_PG_SOURCE" rev-parse --verify 'HEAD^{commit}')" = "$FANFUNNEL_PG_COMMIT"
git -C "$FANFUNNEL_PG_SOURCE" diff --quiet
git -C "$FANFUNNEL_PG_SOURCE" diff --cached --quiet

FANFUNNEL_PG_JOBS=4
FANFUNNEL_PG_CPUS=$(getconf _NPROCESSORS_ONLN)
if (( FANFUNNEL_PG_CPUS < FANFUNNEL_PG_JOBS )); then
  FANFUNNEL_PG_JOBS=$FANFUNNEL_PG_CPUS
fi
cd "$FANFUNNEL_PG_BUILD"
"${FANFUNNEL_PG_SOURCE}/configure" --prefix="$FANFUNNEL_PG_ROOT" \
  --without-readline --without-icu --with-ssl=openssl
make -j "$FANFUNNEL_PG_JOBS"
make install
make -C contrib/pgcrypto -j "$FANFUNNEL_PG_JOBS"
make -C contrib/pgcrypto install

cat > "${FANFUNNEL_PG_ROOT}/BUILD-INFO.txt" <<'FANFUNNEL_PG_BUILD_INFO'
PostgreSQL 16.15
Official source: https://github.com/postgres/postgres.git
Release tag: REL_16_15
Pinned commit: 7d3e000c5961a544302072058a1184e9a588837b
Configure: --prefix=/workspace/.tools/postgresql-16 --without-readline --without-icu --with-ssl=openssl
Extension: pgcrypto
Build prerequisites: C compiler, make, Perl, pkg-config, zlib and OpenSSL headers.
Parser tools: bison, flex, m4, extracted from authenticated Debian trixie packages.
First validated tool versions: bison 3.8.2; flex 2.6.4; m4 1.4.19.
Git HTTPS/TLS and Debian archive signature/package checksum checks remain enabled.
FANFUNNEL_PG_BUILD_INFO
"${FANFUNNEL_PG_ROOT}/bin/postgres" --version
"${FANFUNNEL_PG_ROOT}/bin/psql" --version
"${FANFUNNEL_PG_ROOT}/bin/pg_dump" --version
FANFUNNEL_POSTGRES_INSTALLER
bash "${FANFUNNEL_TOOLS}/fanfunnel-postgres-install.sh"

cat > "${FANFUNNEL_TOOLS}/fanfunnel-env.sh" <<'FANFUNNEL_ENV'
#!/usr/bin/env bash
# Source this file before running FanFunnel development commands.
export PG_BIN="${PG_BIN:-/workspace/.tools/postgresql-16/bin}"
if [[ ! -x "$PG_BIN/pg_ctl" ]]; then
  export PG_BIN=/workspace/.tools/postgresql-16/bin
fi
export PATH="/workspace/.tools/bin:/workspace/.tools/node-v22.23.4-linux-x64/bin:$PG_BIN:$PATH"
export npm_config_cache="/workspace/.cache/npm"
export PLAYWRIGHT_BROWSERS_PATH="/workspace/.cache/ms-playwright"
export NEXT_TELEMETRY_DISABLED=1
export NEXT_PUBLIC_ENABLE_DEBUG="${NEXT_PUBLIC_ENABLE_DEBUG:-1}"
FANFUNNEL_ENV
source "${FANFUNNEL_TOOLS}/fanfunnel-env.sh"

cd "$FANFUNNEL_REPO"
npm ci --no-audit --no-fund

# Prefer the repository's declared test tool; npm ci already installed it.
# Parse failures and a declared-but-missing/wrong version must fail closed.
FANFUNNEL_TSX_DECLARED=$(node - "$FANFUNNEL_REPO" <<'FANFUNNEL_TSX_DECLARATION'
const fs = require('node:fs');
const path = require('node:path');
const pkg = JSON.parse(fs.readFileSync(path.join(process.argv[2], 'package.json'), 'utf8'));
const declarations = [pkg.dependencies, pkg.devDependencies, pkg.optionalDependencies];
console.log(declarations.some(group => group && Object.hasOwn(group, 'tsx')) ? 'yes' : 'no');
FANFUNNEL_TSX_DECLARATION
)
if [[ "$FANFUNNEL_TSX_DECLARED" == yes ]]; then
  node - "$FANFUNNEL_REPO" <<'FANFUNNEL_TSX_LOCAL_CHECK'
const fs = require('node:fs');
const path = require('node:path');
const repo = process.argv[2];
const pkg = JSON.parse(fs.readFileSync(path.join(repo, 'package.json'), 'utf8'));
const versions = [pkg.dependencies, pkg.devDependencies, pkg.optionalDependencies]
  .filter(group => group && Object.hasOwn(group, 'tsx')).map(group => group.tsx);
const installed = JSON.parse(fs.readFileSync(path.join(repo, 'node_modules/tsx/package.json'), 'utf8'));
if (versions.some(version => version !== '4.23.15') || installed.version !== '4.23.15') {
  throw new Error('FanFunnel setup requires the declared and installed tsx 4.23.15');
}
fs.accessSync(path.join(repo, 'node_modules/tsx/dist/cli.mjs'), fs.constants.R_OK);
FANFUNNEL_TSX_LOCAL_CHECK
  FANFUNNEL_TSX_CLI="${FANFUNNEL_REPO}/node_modules/tsx/dist/cli.mjs"
else
  mkdir -p "$FANFUNNEL_TEST_TOOLS"
  if node - "$FANFUNNEL_TEST_TOOLS" <<'FANFUNNEL_TSX_CHECK'
const fs = require('node:fs');
const path = require('node:path');
const directory = process.argv[2];
try {
  const pkg = JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8'));
  const locked = fs.existsSync(path.join(directory, 'package-lock.json'));
  process.exit(locked && pkg.dependencies?.tsx === '4.23.15' ? 0 : 1);
} catch {
  process.exit(1);
}
FANFUNNEL_TSX_CHECK
  then
    npm ci --prefix "$FANFUNNEL_TEST_TOOLS" --no-audit --no-fund
  else
    npm install --prefix "$FANFUNNEL_TEST_TOOLS" --save-exact --no-audit --no-fund tsx@4.23.15
  fi
  # Older checkouts do not declare tsx. Keep that compatible pinned fallback
  # outside the checkout, and link it only in this undeclared branch.
  ln -sfnT "${FANFUNNEL_TEST_TOOLS}/node_modules/tsx" "${FANFUNNEL_REPO}/node_modules/tsx"
  ln -sfnT "${FANFUNNEL_TEST_TOOLS}/node_modules/tsx/dist/cli.mjs" "${FANFUNNEL_REPO}/node_modules/.bin/tsx"

  FANFUNNEL_TSX_CLI="${FANFUNNEL_TEST_TOOLS}/node_modules/tsx/dist/cli.mjs"
fi

cat > "${FANFUNNEL_TOOLS}/fanfunnel-browser-runner.mjs" <<'FANFUNNEL_BROWSER'
// Use the Playwright-managed revision matching the installed package.
import { chromium } from '/workspace/fanfunnel/node_modules/playwright/index.mjs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const target = process.argv[2];
if (!['e2e/run.mjs', 'e2e/a11y.mjs', 'e2e/login-ui.mjs'].includes(target)) {
  throw new Error('Select an existing FanFunnel browser suite.');
}
await import(pathToFileURL(resolve('/workspace/fanfunnel', target)).href);
FANFUNNEL_BROWSER

node --version
npm --version
node "$FANFUNNEL_TSX_CLI" --version
# Install the browser revision locked by this repository's Playwright package.
# System Chromium supports supplementary checks; it does not replace this step.
npx --no-install playwright install chromium
node --input-type=module <<'FANFUNNEL_MATCHING_BROWSER_CHECK'
import { chromium } from '/workspace/fanfunnel/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
try {
  const page = await browser.newPage();
  await page.setContent('<button>Browser ready</button>');
  if (await page.getByRole('button', { name: 'Browser ready' }).count() !== 1) {
    throw new Error('Matching Chromium DOM check failed');
  }
  console.log('Matching Playwright Chromium launch and DOM check: PASS');
} finally {
  await browser.close();
}
FANFUNNEL_MATCHING_BROWSER_CHECK

# Optional platform tooling, outside the application checkout. Authentication
# is established separately through the owner's Vercel browser device flow.
if [[ ! -x /workspace/.tools/vercel-cli/bin/vercel ]] || \
   [[ "$(/workspace/.tools/vercel-cli/bin/vercel --version 2>/dev/null)" != 65.5.0 ]]; then
  npm install --global --prefix /workspace/.tools/vercel-cli vercel@65.5.0 --no-audit --no-fund
fi
mkdir -p /workspace/.tools/bin
cat > /workspace/.tools/bin/vercel <<'FANFUNNEL_VERCEL'
#!/usr/bin/env bash
set -euo pipefail
exec /workspace/.tools/vercel-cli/bin/vercel --global-config /workspace/.tools/vercel-auth "$@"
FANFUNNEL_VERCEL
chmod 755 /workspace/.tools/bin/vercel
vercel --version
