# Repaired common future-source candidate02 — UNRELEASED

This composes original reviewed future work onto exact committed0059 checkpoint
`5877d94b1b9334ce5b0a93baf365dd6fdd5234f1`. It carries the pgcrypto namespace
correction, lazy history, F6 read admission, explicit privacy withdrawal,
transform-only animation and the latest false-only privacy resolution/rescue
for paused links and all archived wheels into every numeric source. No future
feature in this capsule has reached TEST or Preview. Current committed handoff
facts override historical notes. Source reconstruction is not a release pass.

## Portable restore (original environment not needed)

From an extracted addendum:

```sh
python3 restore_repaired.py --repo /absolute/path/to/fanfunnel --output /tmp/fanfunnel-repaired-future-source
```

Output must be NEW and outside the checkout. Git must contain root5877d94. This
uses Python standard library and Git only; verifies all member hashes; applies
and compares every sequential patch/full source tree. It performs no installs,
network, database operations, Git writes or deployments. The restored sources
are candidates for deliberate review/integration, not permission to release.

The sequence is0060 (95paths: original94 plus exact retirement of the one-time
0059 TEST crypto repair workflow invocation),0061 (82: original81 plus reviewed
fixture spacing),0062 (67),0063 (34),0063 safety overlay (7 unique paths), final
hardening (36). **The seven-path safety overlay must be included before the first
0063 full verification, CI or Preview boot.** Complete prior mirror prefixes and
migration files are preserved;13 future crypto changes only alter configuration,
preserving bodies/ACLs/auth/timeouts. The final HANDOFF merge retains current
sections1–2 and the takeover warning, never copying old whole documentation.

35 engagement,72 withdrawal and28 lazy-history regression sources are unchanged
from root. Original38 recovery checks survive the already reviewed0060 actual
controller adaptation, which adds3 wrapper assertions. The latest63data/19rescue
regression sources are preserved, and the three merged data files match all
36 approved preflight outcomes. This preserves tests; it does not claim all were
executed on each composed candidate. Actual syntax counts are recorded in the
source proof. Full unit/build/browser/drift/hosted checks are still pending.

## Optional portable recomposition audit

`compose_repaired.py` also reproduces this composition directly from the original
immutable `future-work-inputs` capsule (SHA3b5086bd...) and the exact latest6-path
privacy authority packaged here. It needs current `dashboard-redesign`
containing the requested committed snapshot in its history, Node on PATH and the repository's installed
TypeScript compiler for complete type-AST preservation checks.

```sh
python3 compose_repaired.py --repo /absolute/path/to/fanfunnel --capsule /tmp/original/future-work-inputs --root-sha 5877d94b1b9334ce5b0a93baf365dd6fdd5234f1 --output /tmp/fanfunnel-recomposition
# The preceding command writes nothing. Use a NEW output with --write after review:
python3 compose_repaired.py --repo /absolute/path/to/fanfunnel --capsule /tmp/original/future-work-inputs --root-sha 5877d94b1b9334ce5b0a93baf365dd6fdd5234f1 --output /tmp/fanfunnel-recomposition-written --write
```

A requestedroot may be5877d94 or a committed documentation/artifact-only descendant.
Every changed non-docspath, including mode changes, is rejected; all approved app
hashes remain exact. Any new root creates new complete source identities and
retains its current committed handoff facts. Dirty working documents are not read
into the Git snapshot; composition performs no checkout writes.

The historical `/workspace/.tools/...` prefix in its authority resolver is a
logical namespace only. Every authority read resolves through the extracted
original capsule, packaged authorities beside this executable, or reconstructed
output; unmapped historical paths are rejected. No original `.tools` directory
is needed. Temporary merges stay in explicit outside-checkout output. Derived
privacy descriptors normalize camelCase keys without modifying the immutable
original manifest; their provenance is included. The mapped controller follows
F6→privacy→animation and never copies a newer game's whole controller earlier.

## Proposed cloud installer — source only

`setup/install.proposed.sh` SHA-256:
`ff5313119711f4d42661060b0c50c1680977dfeabf8ee48d3af13e351cfe4ff0`.
It handles future declared/pinned`tsx@4.23.15` using its actual local CLI, fails
wrong/ranged/missing declared installs and retains the old external fallback
only for an undeclared tool. Twelve targeted controls previously passed. That
is not a full installer pass. Test it only after the pin is live and no verifier
or browser is running, then save complete reviewed cloud setup configuration.
Do not execute/save/publish/restart an environment during active verification.

Before releasing any numeric phase, deliberately integrate onto the latest
verified branch while preserving any newer code/docs, then complete both full
verification rounds including both crypto layouts and e2e→axe on the same fresh
server. Require actual exact-SHA CI/TEST history/types/runtime/login, then exact
Preview deployment and real checks before changing the stable TEST alias. Never
write production Supabase or push/merge main.
