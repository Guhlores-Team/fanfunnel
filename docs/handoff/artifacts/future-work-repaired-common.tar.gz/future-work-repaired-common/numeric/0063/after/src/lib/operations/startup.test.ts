import assert from "node:assert/strict";
import { mock } from "node:test";
let calls = 0, persisted = 0, alerts = 0;
mock.module("@/lib/supabase/server", { namedExports: { createServiceClient: () => ({}), isSupabaseConfigured: () => true } });
mock.module("./canary", { namedExports: { bootstrapEmptyCanary: async () => { calls++; return { status: "mismatch" }; } } });
mock.module("./runtime", { namedExports: { persistHealth: async () => { persisted++; }, reportOperationalFailure: async () => { alerts++; } } });
async function main() {
  const { startupChecksEnabled, registerOperationalChecks } = await import("./startup");
  assert.equal(startupChecksEnabled({ NEXT_RUNTIME: "edge" }), false);
  assert.equal(startupChecksEnabled({ NEXT_RUNTIME: "nodejs", NEXT_PHASE: "phase-production-build" }), false);
  assert.equal(startupChecksEnabled({ NEXT_RUNTIME: "nodejs" }), true);
  process.env.NEXT_RUNTIME = "nodejs"; process.env.NEXT_PHASE = "phase-production-build";
  await registerOperationalChecks(); assert.equal(calls, 0, "build does not access the database");
  delete process.env.NEXT_PHASE;
  await Promise.all([registerOperationalChecks(), registerOperationalChecks(), registerOperationalChecks()]);
  await registerOperationalChecks();
  assert.equal(calls, 1, "concurrent startup registrations run once, never per request");
  assert.equal(persisted, 1); assert.equal(alerts, 1);
  console.log("operational startup: 7 checks passed; no build-time remote effects or real alerts");
}
main().catch(error => { console.error(error); process.exitCode = 1; });
