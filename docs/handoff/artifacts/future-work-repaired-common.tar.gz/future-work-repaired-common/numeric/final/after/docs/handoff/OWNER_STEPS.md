# FanFunnel — owner steps for safe TEST acceptance

The current work stays on `dashboard-redesign` and its TEST Preview. This checklist
does not authorize Production changes, copying data to Production, purchases,
pushing/merging to `main`, or release approval. Engineers must complete the
ordered migrations, two full verification rounds, green exact-revision CI,
TEST database/type/security checks and controlled Preview deployment first.

**Current manual status: NOT VERIFIED unless a dated result says otherwise.**
The owner has already confirmed FanFunnel admin two-factor enrollment; do not
remove or repeat it to test setup. Local preparation and automated results do not
mean the owner has accepted a hosted feature. Follow one step at a time with the
engineer. Use disposable TEST accounts and dummy inventory only.

Never paste passwords, API keys, reward keys, downloaded exports, fan links,
authenticator QR codes or six-digit codes into chat. Enter credentials only on
the relevant website. Your authenticator app generates the codes automatically;
there is no need to invent random codes. Recovery information belongs in your
private password manager, not a screenshot or a bug report.

## 1. Start with the correct environment

1. Open [the TEST dashboard](https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app/dashboard).
2. Sign in using your FanFunnel TEST account; complete an authenticator prompt only on the website if asked.
3. Confirm the teal **PREVIEW · TEST database** badge; stop if a red badge appears.
4. Ask the engineer which exact verified revision is on this URL and which new features are available.
5. Ask the engineer to prepare disposable creator/fan accounts and dummy prizes for the available features.

The stable URL is reused for successive verified TEST releases. An older immutable
Preview URL is not the acceptance target. Every manual result should record the
revision, date, phone/browser, PASS/FAIL and any redacted failure description.

## 2. Keep provider accounts and recovery safe

These are account-security checks, not instructions to change a Production app.
Existing protections should stay on. Have anyone with account access check their
own security separately; never share a login or authenticator secret.

1. Check two-step verification on [your Google account](https://myaccount.google.com/signinoptions/twosv), if it owns your login email.
2. Check two-factor authentication on [GitHub security](https://github.com/settings/security).
3. Check two-factor authentication on [your Vercel account](https://vercel.com/account).
4. Check multi-factor authentication on [your Supabase account](https://supabase.com/dashboard/account/security).
5. Check your [Resend account](https://resend.com) security settings, if used.
6. Check your [Upstash account](https://console.upstash.com) security settings, if used; GitHub sign-in relies on your GitHub protection.
7. Save provider recovery codes privately in a password manager; provider recovery codes are separate from FanFunnel's admin-assisted recovery.
8. Ask the engineer to confirm a second trusted TEST admin exists before relying on recovery.
9. Have that second admin sign in at [TEST Admin](https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app/admin) and complete their own two-factor challenge.
10. Rehearse **Reset two-factor** on a disposable creator only, following [the manual security checks](../../e2e/MANUAL-CHECKLIST.md#16-unknown-outcomes-cancellation-and-security-recovery).

Every admin must use two-factor for admin access. An enrolled creator must also
verify for authenticated business access. A verified session can remain verified
until sign-out or session expiry; a new code is not required on every click. Do
not experiment on the owner's only working admin or assume a backup admin works
without actually signing in.

## 3. Check TEST sign-in and email configuration with the engineer

1. Open [TEST password protection](https://supabase.com/dashboard/project/snmcrmhgevfqggxdiomu/auth/protection) and review leaked-password protection with the engineer; record if your plan does not provide it.
2. Review email confirmation with the engineer in [TEST Auth providers](https://supabase.com/dashboard/project/snmcrmhgevfqggxdiomu/auth/providers); email confirmation must remain on.
3. Review [TEST URL configuration](https://supabase.com/dashboard/project/snmcrmhgevfqggxdiomu/auth/url-configuration); the intended stable TEST Site URL is `https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app`.
4. Request a password-reset email for a disposable TEST account; its link reaches the TEST site and completes the intended flow.
5. Test a disposable creator's email change; any required current-password and authenticator checks happen on the website.

An engineer must review changes and allowed return URLs before saving them. No
Production Supabase settings are part of this checklist. If a service asks for a
paid upgrade, record that decision; this checklist does not buy it.

## 4. Back up the reward keys before any real inventory

**NOT VERIFIED.** There are two different server-side reward secrets: the reward
encryption key and the stable code-fingerprint key. The encryption key version
must also be retained. A valid-looking replacement cannot recover old ciphertext
or prove erased-code non-reuse. Do not rotate keys as a troubleshooting shortcut.

1. Open [FanFunnel environment settings](https://vercel.com/easy-simple-sites/fanfunnel/settings/environment-variables) with the engineer and confirm the relevant values are scoped to **Preview** only for this work.
2. With the engineer, securely save the existing Preview encryption key, its version and stable fingerprint key to the private password manager without displaying them in chat or logs.
3. Ask the engineer to rehearse restoring a disposable TEST backup with those original values; record the redacted result.
4. Ask the engineer to prove that saved dummy rewards decrypt and erased dummy codes remain refused after that rehearsal.
5. Keep real-value inventory blocked until the backup/restore result and key-protection checks below are verified.

If the existing sensitive value cannot be retrieved safely, stop and use the
existing secure backup/operator recovery path. Do not generate a replacement and
call it a backup. A data backup and a key backup are both needed for recovery.

## 5. Check System health only after its verified TEST rollout

Prerequisite: the engineer confirms the operations release is on the exact TEST
Preview. Prepared UI is not a deployment. A scheduled job, alert or canary is
**NOT VERIFIED** just because its button exists.

1. Open [TEST Admin](https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app/admin) and find **System health**.
2. Select **Refresh status**; **Demo only** is not a connected-database pass.
3. If protection is missing, confirm the private backup/restore prerequisites in §4 before touching initialization.
4. Only when that backup is true, tick **I have securely backed up both reward keys and the encryption key version.**
5. Select **Initialize reward key protection** only if the missing-record UI offers it; an existing record must never be replaced to hide a mismatch.
6. Select **Run checks now**; review both the reward-key protection message and the latest inventory, reservation and credit checks.
7. If checks are incomplete, mismatched or require recovery, report the exact redacted message and leave real inventory and Chase blocked.
8. After the engineer restores the original configuration for a failure, select **Run checks now** again; only a successful check clears the recorded failure.
9. Ask the engineer to demonstrate a separate authenticated TEST maintenance run and the later daily scheduled run; compare **Last authenticated maintenance** timestamps.
10. Ask the engineer to send a safe TEST diagnostic alert to the intended private inbox; confirm actual receipt without including a key, code or fan link.

Health output contains states, timestamps and mismatch counts only. The checks do
not repair balances or issue rewards. **Recovery required** after historical
code erasure needs an operator and the original keys/database backup; never bless
a new protection record. A manual run does not prove daily scheduling, storage
cleanup completion or email delivery.

## 6. Accept the visible product on real devices

1. Open [the complete TEST manual checklist](../../e2e/MANUAL-CHECKLIST.md) and record its revision/date/device before testing.
2. Complete the original creator, phone, fan, install and win-back cases (§1–7) using only disposable TEST data.
3. Complete privacy/export/deletion and two-factor checks (§9); downloaded private data stays off chat.
4. Complete iPhone installed-dashboard and Android push checks (§10); a desktop simulation does not count.
5. Complete instant reward checks with dummy codes only (§11), including history, public-proof secrecy and erasure.
6. Complete font/photo/contrast and admin photo-removal checks (§12).
7. Review the engineer's [controlled themed Preview LCP result](../PREVIEW_PERFORMANCE.md) with its phone/cache conditions; mark it unverified until that measurement exists.
8. Complete Focus acceptance (§13); review cost warnings and keep Chase hosted off.
9. Complete Scratch checks (§14) only after the **Scratch Tickets** TEST feature gate is enabled.
10. Complete personal Bingo checks (§15) only after the separate **Bingo** TEST feature gate and ready draft are verified.
11. Complete interrupted-request, cancellation, authenticator recovery, invitation expiry and last-admin checks with the engineer's fixtures (§16).
12. Complete the TEST smoke scenario (§4); record failures instead of treating a blocked or unavailable feature as a pass.

Focus is a boost, not a guarantee. Chase remains hosted **OFF** until documented
Focus soak and explicit approval for **one TEST creator**. That pilot needs its
own reservation/guarantee/replay checks and healthy diagnostics; passing this
checklist does not enable Chase or approve a broader rollout.

Every credited primary play wins. Bingo line bonuses use no extra credit or paid
play count. A recoverable sold-out candidate uses a recorded redraw from the
committed pool; an unrecoverable held-stock/key failure refuses before debit.
The old proposal's manual-pending fallback is not an implemented promise.

## 7. Open operational checks — all NOT VERIFIED here

Each line needs independent dated evidence; a local preparation report is not an
operations pass. The engineer owns the technical setup and redacted proof.

- [ ] **TEST daily scheduler — INACTIVE / NOT VERIFIED.** Confirm authenticated retention/storage and diagnostic work runs on schedule, records fresh timestamps and reports failures; a manual button is insufficient. The [scheduler preparation](TEST_MAINTENANCE.md) is source only; configuration is not execution proof. Resolve any [legacy key-enrollment gate](LEGACY_CANARY_BOOTSTRAP.md) before initialization or scheduler activation.
- [ ] **Old Preview URLs — NOT RETIRED.** List the old immutable deployments and branch recreation paths; ask the owner to approve the concrete retirement plan only after the replacement Preview is fully verified. No retirement is authorized by this checklist.
- [ ] **Both reward keys + version — NOT VERIFIED.** Confirm private backup of the original encryption key, version and stable fingerprint key before real inventory.
- [ ] **Restore rehearsal — NOT VERIFIED.** Demonstrate the disposable TEST database/key restore, dummy reward access and preserved erased-code non-reuse.
- [ ] **Second admin — NOT VERIFIED.** Demonstrate separate sign-in, mandatory two-factor and disposable-account recovery.
- [ ] **Alert delivery — NOT VERIFIED.** Demonstrate actual redacted TEST error/health alert receipt and usable failure guidance.
- [ ] **Real iPhone/Android installation and push — NOT VERIFIED.** Record real device permission, background receipt, privacy and tap results.
- [ ] **Themed Preview LCP — NOT VERIFIED.** Measure the controlled photo/font fixture on the verified TEST Preview and save the conditions/result.
- [ ] **Final security review — NOT VERIFIED by this document.** Complete the required fresh independent audits, hosted negative tests and the primary review before claiming the internal tool ready.

## 8. Decisions kept separate from TEST acceptance

1. Read [TEST Terms](https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app/terms) and note requested wording changes.
2. Read [TEST Privacy](https://fanfunnel-git-dashboard-redesign-easy-simple-sites.vercel.app/privacy) and check the actual export, deletion, retention and photo promises.
3. Review the saved legal questions with counsel, including prize/sweepstakes, adult-content and privacy obligations; choosing an entity/operator name is an owner decision.
4. Review the saved product defaults with the engineer, especially opt-in Boostable prizes, price/cost warnings, lock-screen details and the one-creator Chase gate.
5. Review [GitHub repository security](https://github.com/Guhlores-Team/fanfunnel/settings/security_analysis) and keep secret scanning, push protection and dependency alerts enabled where the plan permits.
6. Review [GitHub environment protections](https://github.com/Guhlores-Team/fanfunnel/settings/environments) and [branch rules](https://github.com/Guhlores-Team/fanfunnel/settings/branches) with the engineer; preserve the required-reviewer/green-check gates on any future release.

Domain purchase, support inbox, paid hosting/database plans, live sender setup,
uptime service and possible future selection of TEST data are deferred owner
decisions. The former go-live/copy-to-live sequence is outside this takeover's
TEST-only authorization. A future release needs its own concrete review and
explicit authorization; no box here approves a main merge or Production write.
