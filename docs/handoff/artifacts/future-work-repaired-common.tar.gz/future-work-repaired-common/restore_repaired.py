#!/usr/bin/env python3
"""Verify source-only capsule and reconstruct its REPAIRED-COMMON candidate sources outside Git.

This reconstructs the reviewed common repairs from checkpoint5877d94.
It does not run application or release checks.
No network, Git writes, credentials, database calls or deployments are performed.
"""
import argparse, hashlib, io, json, os, shutil, subprocess, tarfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
SKIP = {'.git', '.next', 'node_modules'}
def sha(data): return hashlib.sha256(data).hexdigest()
def tree(rows): return sha(''.join(name+'\0'+sha(value[1])+'\n' for name,value in sorted(rows.items())).encode())
def source_map(folder):
 rows={}
 for p in folder.rglob('*'):
  rel=p.relative_to(folder)
  if SKIP.intersection(rel.parts): continue
  if p.is_symlink():rows[rel.as_posix()]=('link',os.readlink(p).encode())
  elif p.is_file():rows[rel.as_posix()]=('file',p.read_bytes())
 return rows

def write(folder,rows):
 assert not folder.exists(),f'Refusing to overwrite: {folder}'
 folder.mkdir(parents=True,mode=0o700)
 for name,(kind,data) in rows.items():
  rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
  p=folder/rel;p.parent.mkdir(parents=True,exist_ok=True)
  if kind=='link':
   target=Path(data.decode());assert not target.is_absolute() and (p.parent/target).resolve().is_relative_to(folder.resolve())
   p.symlink_to(data.decode())
  else:p.write_bytes(data)

def verify_members():
 expected={}
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);assert len(digest)==64 and not Path(name).is_absolute() and '..' not in Path(name).parts
  assert name not in expected
  expected[name]=digest
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
 assert actual==set(expected),'Capsule members added or missing'
 for name,digest in expected.items():assert sha((ROOT/name).read_bytes())==digest,f'Changed capsule member: {name}'
 assert not any(p.is_symlink() for p in ROOT.rglob('*')),'Unexpected capsule link'
 return len(expected)

def archive(repo,commit):
 raw=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar',commit]);rows={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as stream:
  for item in stream:
   p=Path(item.name);assert not p.is_absolute() and '..' not in p.parts
   if item.isfile():rows[item.name]=('file',stream.extractfile(item).read())
   elif item.issym():rows[item.name]=('link',item.linkname.encode())
   else:assert item.isdir()
 return rows

def layout(rows):
 name='src/lib/data/db.types.ts';old=b'        Row: { actor_id: string; created_at: string; id: string; kind: string }'
 new=b'        Row: {\n          actor_id: string\n          created_at: string\n          id: string\n          kind: string\n        }'
 data=rows[name][1];assert data.count(old)==1 and data.count(new)==0
 rows=dict(rows);rows[name]=('file',data.replace(old,new));return rows

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--repo',type=Path,required=True)
 parser.add_argument('--output',type=Path,required=True,help='New directory outside the repository')
 parser.add_argument('--check-only',action='store_true',help='Verify all members and exact historical compositions without writing source trees')
 args=parser.parse_args();repo=args.repo.resolve();out=args.output.resolve()
 assert repo.is_dir() and (repo/'.git').exists(),'Supply FanFunnel repository'
 assert not out.is_relative_to(repo) and not repo.is_relative_to(out),'Output must be separate from checkout'
 assert not out.exists(),'Output must not exist'
 member_count=verify_members();index=json.loads((ROOT/'INDEX.json').read_text())
 rows=archive(repo,index['historicalRootGitCommit']);root_name='repaired-root-0059-5877d94'
 assert tree(rows)==index['phases'][0]['baseTree'],'Historical Git base differs'
 if not args.check_only:write(out/root_name,rows)
 reports=[];aliases={str(Path(index['phases'][0]['originalBase'])):str(out/root_name)}
 prior_output=out/root_name
 for phase in index['phases']:
  if phase.get('requiresCancellationRowLayoutBefore'):
   rows=layout(rows)
   typed_base=out/Path(phase['originalBase']).name
   if not args.check_only:write(typed_base,rows)
   aliases[phase['originalBase']]=str(typed_base);prior_output=typed_base
  assert tree(rows)==phase['baseTree'],f'Wrong historical base: {phase["phase"]}'
  manifest=ROOT/phase['manifest'];assert sha(manifest.read_bytes())==phase['manifestSha256']
  before=dict(rows)
  for entry in phase['entries']:
   name=entry['path'];current=rows.get(name,('file',None))[1]
   assert (sha(current) if current is not None else None)==entry['before_sha256'],f'Baseline mismatch: {phase["phase"]}/{name}'
   content=(ROOT/entry['portableSource']).read_bytes();assert sha(content)==entry['after_sha256']
   rows[name]=('file',content)
  assert tree(rows)==phase['sourceTree'],f'Whole reconstructed source mismatch: {phase["phase"]}'
  if phase.get('sourceFiles'):assert len(rows)==phase['sourceFiles']
  destination=out/Path(phase['originalSource']).name
  if not args.check_only:
   write(destination,rows)
   patch_work=out/('patch-proof-'+phase['phase'])
   shutil.copytree(prior_output,patch_work,symlinks=True)
   for check in [True,False]:
    command=['git','apply']+(['--check'] if check else [])+[str(ROOT/phase['patch'])]
    result=subprocess.run(command,cwd=patch_work,capture_output=True,text=True)
    assert result.returncode==0,f'Patch rejected {phase["phase"]}: {result.stderr}'
   assert source_map(patch_work)==rows,f'Patch/full reconstruction differ: {phase["phase"]}'
   shutil.rmtree(patch_work)
  aliases[phase['originalSource']]=str(destination);prior_output=destination
  reports.append({'phase':phase['phase'],'changedPaths':len(phase['entries']),'files':len(rows),'sourceTreeSha256':tree(rows),'patchAppliedAndCompared':not args.check_only})
 result={'kind':'REPAIRED_COMMON_CANDIDATE_RECONSTRUCTION_ONLY','membersVerified':member_count,'historicalRootGitCommit':index['historicalRootGitCommit'],'phases':reports,'reviewedRoot5877CommonRepairsIntegrated':True,'fullVerification':False,'hostedActions':False,'originalDirectoryAliases':aliases}
 if not args.check_only:(out/'reconstruction-report.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
