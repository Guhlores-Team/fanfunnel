#!/usr/bin/env python3
"""Reassemble reviewed numeric sources outside Git from a clean repaired0059.

Nothing runs on import. No hosted commands, Git mutations, installs or releases.
All existing source authorities are read only. A write creates a NEW generation.
"""
import argparse
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile
import shutil

TASK = Path('/workspace/.tools/fanfunnel-takeover')  # Logical historical namespace only; resolved from capsule
REPO = None
CAPSULE = None
ALIASES = {}
MANIFESTS = {}
FILE_ALIASES = {}
TEMP_ROOT = None
OUTPUT_ROOT = None
START_HEAD = None
HERE = Path(__file__).resolve().parent
OLD_ROOT = '9642dfd4d24518c201f736f93387443e43d80a8f'
EXPECTED_ROOT = '5877d94b1b9334ce5b0a93baf365dd6fdd5234f1'
AUTHORITIES = {
    '0060': 'c32bd32220c7e19f8a6ac8e12956c7503aae2361444b6944521c80551f82fe77',
    '0061': 'f53218839b1ab33ed26de422925d4aaf10d30d1fc609febe211edb4404081891',
    '0062': '187fa36a0e370c8ed666f7d09e301fc28fc4c91018ace2424a4d303ddd7fe326',
    '0063': 'c2e61caa523a9e3690f827a8f35e77d7bfafa88ec3835f7144d3f1ab15bb8be7',
}
FINAL_SHA = '29c968d6f0a95aa73a2c38a7b585e8665f7e1d1f2d31b2b68a2f439c60f7f177'
CRYPTO_SHA = '3b0c64cc271da36d22d02e995dd4a65aad0659a46bf7f97bb106f1a7400e893c'
UI_SHA = '1e683b91579fc3018e55004b7a960d80d705d9cce6006f718c9ed64d7a2341e3'
MAP_SHA = '94ab7b621cf53a73d2bfdc49c99b825d042c379139f46e3fc3aae6d5a5700107'
FIXTURE_SHA = '225f727367165de5ee0d3a47d97950b389ef5229fb529bdf562108b80d2b72d2'
SAFETY_SHA = '06fc48b9574f042b4b8627bb5253273581b437ea8317a03844527290ec19e14d'
SKIP = {'node_modules', '.next', '.git'}
TYPE_PATH = 'src/lib/data/db.types.ts'
MIRRORS = {'supabase/schema.sql', 'supabase/migrations_combined.sql'}
WORKFLOW = '.github/workflows/supabase-migrations.yml'
CRYPTO_TAIL = (b'    const cryptoFailures = probeCryptoNamespace(db, psql, CRYPTO_SCHEMA);\n'
               b'    if (cryptoFailures.length) throw new Error(cryptoFailures.join("; "));\n')
LOOP_END = b'  }\n} catch (e) {\n  failures++;'
REPAIR_INVOCATION = (b'      # One-time0059 TEST prerelease correction: retire this invocation with0060.\n'
                     b'      # The helper only changes15 validated function search paths; no data/history.\n'
                     b'      - name: Correct verified0059 TEST crypto search paths\n'
                     b'        env:\n'
                     b'          SUPABASE_TEST_PROJECT_REF: ${{ secrets.SUPABASE_TEST_PROJECT_REF }}\n'
                     b'        run: node scripts/db/repair-test-crypto-0059.mjs\n')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def resolved(path):
    path = Path(path)
    key = str(path)
    if key in MANIFESTS: return MANIFESTS[key]
    if key in FILE_ALIASES: return FILE_ALIASES[key]
    for old, new in sorted(ALIASES.items(), key=lambda row: len(row[0]), reverse=True):
        if key == old or key.startswith(old + '/'):
            return Path(new) / key[len(old):].lstrip('/')
    assert any(root is not None and path.resolve().is_relative_to(root) for root in [CAPSULE, OUTPUT_ROOT, HERE / 'authorities']), f'Unmapped source authority: {path}'
    assert path.exists(), f'Missing portable source authority: {path}'
    return path


def pinned(path, expected):
    path = resolved(path)
    raw = path.read_bytes()
    assert sha(raw) == expected, f'Authority identity changed: {path}'
    return json.loads(raw)


def file_map(root):
    result = {}
    for path in root.rglob('*'):
        rel = path.relative_to(root)
        if SKIP.intersection(rel.parts):
            continue
        if path.is_symlink():
            result[rel.as_posix()] = ('link', os.readlink(path).encode())
        elif path.is_file():
            result[rel.as_posix()] = ('file', path.read_bytes())
    return result


def archive_map(commit):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(git('archive', '--format=tar', commit)), mode='r:') as archive:
        for item in archive:
            path = Path(item.name)
            assert not path.is_absolute() and '..' not in path.parts
            if item.isfile():
                result[item.name] = ('file', archive.extractfile(item).read())
            elif item.issym():
                result[item.name] = ('link', item.linkname.encode())
            else:
                assert item.isdir(), f'Unexpected archive object: {item.name}'
    return result


def tree(rows):
    return sha(''.join(name + '\0' + sha(value[1]) + '\n'
                       for name, value in sorted(rows.items())).encode())


def write_map(folder, rows):
    assert not folder.exists(), f'Refusing to overwrite prior generation: {folder}'
    folder.mkdir(parents=True, mode=0o700)
    for name, (kind, content) in rows.items():
        path = folder / name
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        path.parent.mkdir(parents=True, exist_ok=True)
        if kind == 'link':
            path.symlink_to(content.decode())
        else:
            path.write_bytes(content)


def layout(data):
    old = b'        Row: { actor_id: string; created_at: string; id: string; kind: string }'
    new = b'        Row: {\n          actor_id: string\n          created_at: string\n          id: string\n          kind: string\n        }'
    if data.count(old) == 1:
        return data.replace(old, new)
    assert data.count(old) == 0 and data.count(new) == 1, 'Unknown cancellation Row layout'
    return data


def merge_text(current, before, after, label, conflicts):
    if current == after or before == after:
        return current, 'already_after_or_current_preserved'
    if current == before:
        return after, 'exact_historical_delta'
    if before is None:
        assert current is None, f'Unexpected added-file collision: {label}'
        return after, 'added'
    assert current is not None, f'Missing current path: {label}'
    with tempfile.TemporaryDirectory(dir=TEMP_ROOT, prefix='merge-') as directory:
        directory = Path(directory)
        for name, data in [('ours', current), ('base', before), ('theirs', after)]:
            (directory / name).write_bytes(data)
        result = subprocess.run(['git', 'merge-file', '-p', '-L', 'NEW_prior', '-L', 'frozen_before',
                                 '-L', 'frozen_feature', str(directory / 'ours'), str(directory / 'base'),
                                 str(directory / 'theirs')], capture_output=True)
    if result.returncode:
        conflicts.mkdir(parents=True, exist_ok=True)
        (conflicts / label.replace('/', '__')).write_bytes(result.stdout)
        raise AssertionError(f'Unreviewed merge conflict: {label}')
    return result.stdout, 'three_way_clean'


def source_entry(manifest, entry):
    path = entry['path']
    source = resolved(Path(manifest['source']) / path)
    content = source.read_bytes()
    assert sha(content) == entry.get('after_sha256', entry.get('sha256')), path
    return content


def apply_reviewed_overlay(rows, descriptor, provenance):
    manifest = pinned(Path(descriptor['manifest']), descriptor['sha256'])
    entries = manifest.get('files', manifest.get('entries'))
    assert entries, 'Empty overlay authority'
    for entry in entries:
        name = entry['path']
        actual = rows.get(name, ('file', None))[1]
        assert (sha(actual) if actual is not None else None) == entry['before_sha256'], f'Overlay baseline changed: {name}'
        rows[name] = ('file', source_entry(manifest, entry))
        provenance.append({'path': name, 'method': 'exact_separately_reviewed_overlay',
                           'manifest_sha256': descriptor['sha256']})


def assert_config_only(before, after):
    old_lines, new_lines = before.splitlines(keepends=True), after.splitlines(keepends=True)
    assert len(old_lines) == len(new_lines), 'Outside approved configuration line replacement'
    changes = 0
    for old, new in zip(old_lines, new_lines):
        if old == new:
            continue
        assert old.lstrip().startswith((b'returns ', b'language '))
        assert new.lstrip().startswith((b'returns ', b'language '))
        assert re.search(rb'set search_path\s*=\s*public(?=\s+(?:as|set)\b)', old)
        assert b'set search_path=public,extensions,pg_temp' in new
        normal_old = re.sub(rb'set search_path\s*=\s*public(?=\s+(?:as|set)\b)', b'set search_path=public', old)
        normal_new = new.replace(b'set search_path=public,extensions,pg_temp', b'set search_path=public')
        assert normal_old == normal_new, 'Business statement, timeout or ACL changed'
        changes += 1
    assert changes > 0, 'No reviewed configuration changes found'
    return changes


def prove_type_layout(before, after):
    assert layout(before) == after, 'Type authority has an unapproved non-layout difference'
    node = Path(shutil.which('node') or '')
    compiler = REPO / 'node_modules/typescript/lib/typescript.js'
    assert node.is_file() and compiler.is_file(), 'Retained read-only AST tools unavailable'
    javascript = r'''
const fs=require('fs'),ts=require(process.argv[4]);
function signature(file){
  const source=ts.createSourceFile('db.types.ts',fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  if(source.parseDiagnostics.length)throw Error('Invalid type source');
  let count=0;
  function visit(node){count++;const children=[];ts.forEachChild(node,child=>{children.push(visit(child));});
    return[node.kind,children.length?null:node.text??null,node.escapedText??null,children];}
  return{nodes:JSON.stringify(visit(source)),count};
}
const before=signature(process.argv[2]),after=signature(process.argv[3]);
if(before.nodes!==after.nodes)throw Error('Database type AST changed');
process.stdout.write(JSON.stringify({completeTypeScriptAstEqual:true,nodes:after.count,compiler:ts.version}));
'''
    with tempfile.TemporaryDirectory(dir=TEMP_ROOT, prefix='types-') as directory:
        directory = Path(directory)
        (directory / 'before.ts').write_bytes(before)
        (directory / 'after.ts').write_bytes(after)
        result = subprocess.run([str(node), '-', str(directory / 'before.ts'), str(directory / 'after.ts'),
                                 str(compiler)], input=javascript, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


def freeze(folder, phase, before, after, source, base_source, authority, provenance):
    changed = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
    assert set(before) <= set(after), 'Unexpected source deletion'
    folder.mkdir(parents=True)
    entries = []
    patch = ''
    for name in changed:
        exists = name in before
        old = before.get(name, ('file', b''))
        new = after[name]
        assert old[0] == new[0] == 'file', f'Unexpected changed symlink: {name}'
        for sub, content in [('before', old[1]), ('after', new[1])]:
            path = folder / sub / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        entries.append({'path': name, 'status': 'modified' if exists else 'added', 'baseline_exists': exists,
                        'before_sha256': sha(old[1]) if exists else None,
                        'after_sha256': sha(new[1]), 'bytes': len(new[1])})
        patch += ''.join(difflib.unified_diff(old[1].decode().splitlines(True), new[1].decode().splitlines(True),
                                            fromfile='a/' + name if exists else '/dev/null', tofile='b/' + name))
    (folder / 'numeric.patch').write_text(patch)
    reconstruction = folder / 'reconstruction'
    write_map(reconstruction, before)
    for arguments in [['git', 'apply', '--check', str(folder / 'numeric.patch')],
                      ['git', 'apply', str(folder / 'numeric.patch')]]:
        result = subprocess.run(arguments, cwd=reconstruction, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
    assert file_map(reconstruction) == after, 'Complete source reconstruction changed'
    manifest = {'phase': phase, 'source': str(source), 'base': str(base_source), 'source_tree_sha256': tree(after),
                'source_files': len(after), 'base_tree_sha256': tree(before),
                'historical_authority': authority, 'files': entries,
                'patch_sha256': sha(patch.encode()), 'provenance': provenance,
                'reconstruction': f'{len(entries)}/{len(entries)} changed paths and whole tree exact',
                'verification': 'Composition only; focused/full/root/hosted checks pending',
                'live_or_hosted_writes': False}
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return {'phase': phase, 'paths': len(changed), 'manifest': str(folder / 'manifest.json'),
            'manifest_sha256': sha((folder / 'manifest.json').read_bytes()), 'tree': tree(after)}


def reassemble(root_sha, generation, approval):
    assert subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', EXPECTED_ROOT, root_sha], capture_output=True).returncode == 0, 'Requested snapshot must descend from approved5877d94'
    changed = git('diff', '--name-only', '-z', '--no-renames', EXPECTED_ROOT, root_sha).split(b'\0')
    assert not [name for name in changed if name and not name.startswith(b'docs/')], 'Only committed documentation/artifact changes may extend approved app snapshot'
    assert git('branch', '--show-current').decode().strip() == 'dashboard-redesign'
    assert subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', root_sha, 'HEAD'], capture_output=True).returncode == 0, 'Reviewed root must be in current branch history'
    assert approval.get('rootCommit') == root_sha and approval.get('rootReviewedCommonCrypto') is True
    assert approval.get('rootApprovedCryptoProbeOrdering') is True
    assert approval.get('rootApprovedFutureCryptoManifest') == CRYPTO_SHA
    assert not generation.exists(), 'Create a new generation; never overwrite'
    numeric = {phase: pinned(TASK / f'phase-{phase}-compatible-final/manifest.json', digest)
               for phase, digest in AUTHORITIES.items()}
    future_crypto = pinned(TASK / 'crypto-namespace-future-overlays/manifest.json', CRYPTO_SHA)
    crypto = {row['phase']: row for row in future_crypto['phases']}
    ui = pinned(TASK / 'ui-engagement-repair-01/common-manifest.json', UI_SHA)
    mapped = pinned(TASK / 'ui-engagement-repair-01/mapped-controller-manifest.json', MAP_SHA)
    fixture = pinned(TASK / 'ui-engagement-repair-01/fixture-manifest.json', FIXTURE_SHA)
    safety = pinned(TASK / 'final-hardening-compatible-02-release-safety-base.json', SAFETY_SHA)
    final = pinned(TASK / 'final-hardening-compatible-03-manifest.json', FINAL_SHA)
    immutable_sources = {}
    for phase, manifest in numeric.items():
        old_rows = file_map(resolved(Path(manifest['source'])))
        assert tree(old_rows) == manifest['source_tree_sha256'], f'Frozen source changed: {phase}'
        immutable_sources[manifest['source']] = tree(old_rows)
    final_old_rows = file_map(resolved(Path(final['source'])))
    assert tree(final_old_rows) == final['sourceTreeSha256'], 'Frozen final source changed'
    immutable_sources[final['source']] = tree(final_old_rows)
    root_rows = archive_map(root_sha)
    common_crypto = pinned(TASK / 'crypto-namespace-repair-final-manifest.json',
                           '8d6b499d05ae19015673bfb7ed93375c5dce09827c6fcdcb615fed8c45cec457')
    for entry in common_crypto['files']:
        assert sha(root_rows[entry['path']][1]) == entry['after_sha256'], 'Root reviewed crypto source differs'
    late_privacy = pinned(TASK / 'leaderboard-withdrawal-privacy-repair-01/manifest.json',
                          'aa0a0fbdac8e488232f3d2d8e83b1b75442819dc29fca64773746d5247b6aae7')
    for entry in late_privacy['files']:
        assert sha(root_rows[entry['path']][1]) == entry['afterSha256'], 'Latest root privacy repair differs'
    original_root = archive_map(OLD_ROOT)
    assert max(name.split('/')[-1][:4] for name in root_rows if name.startswith('supabase/migrations/') and name.endswith('.sql')) == '0059'
    approved_parent_common = {}
    for entry in ui['files']:
        approved_parent_common[entry['path']] = ('file', source_entry(ui, entry))
    # A subsequent privacy correction may extend the same parent/test and add
    # an explicit withdrawal-only control. Every intermediate hash is checked;
    # the old F6 authority remains immutable and is never silently superseded.
    for descriptor in approval.get('approvedParentPrivacyManifests', []):
        manifest = pinned(Path(descriptor['manifest']), descriptor['sha256'])
        for entry in manifest.get('files', manifest.get('entries')):
            name = entry['path']
            prior = approved_parent_common.get(name, original_root.get(name, ('file', None)))[1]
            assert (sha(prior) if prior is not None else None) == entry['before_sha256'], name
            approved_parent_common[name] = ('file', source_entry(manifest, entry))
    animation = pinned(TASK / 'scratch-a11y-transform-repair-01/manifest.json',
                       '1635e98523771141aa0ac09cbeba497940c3b650ab48b8603e2deac7f5b4c955')
    literal_before, literal_after = animation['literalBefore'].encode(), animation['literalAfter'].encode()
    parent_name = 'src/components/SpinClient.tsx'
    parent = approved_parent_common[parent_name][1]
    assert parent.count(literal_before) == 1 and parent.count(literal_after) == 0
    approved_parent_common[parent_name] = ('file', parent.replace(literal_before, literal_after))
    for name, expected in approved_parent_common.items():
        assert root_rows[name] == expected, 'Root parent common is not the final approved chain'
    approved_controller = source_entry(mapped, mapped['files'][0])
    for descriptor in approval.get('approvedMappedPrivacyManifests', []):
        privacy = pinned(Path(descriptor['manifest']), descriptor['sha256'])
        assert len(privacy['files']) == 1
        entry = privacy['files'][0]
        assert sha(approved_controller) == entry['before_sha256']
        approved_controller = source_entry(privacy, entry)
    assert approved_controller.count(literal_before) == 1 and approved_controller.count(literal_after) == 0
    approved_controller = approved_controller.replace(literal_before, literal_after)
    assert root_rows[WORKFLOW][1].count(REPAIR_INVOCATION) == 1
    retired_workflow = root_rows[WORKFLOW][1].replace(REPAIR_INVOCATION, b'')
    assert retired_workflow == original_root[WORKFLOW][1], 'Retirement must preserve the original complete workflow'
    current = dict(root_rows)
    write_map(generation / 'root0059', root_rows)
    prior_source = generation / 'root0059'
    reports = []
    for phase, manifest in numeric.items():
        before_new = dict(current)
        old_base = resolved(Path(manifest['base']))
        old_source = resolved(Path(manifest['source']))
        overlay = crypto[phase]
        migration_path = overlay['path']
        old_migration = (old_source / migration_path).read_bytes()
        fixed_migration = resolved(Path(overlay['source'])).read_bytes()
        assert sha(old_migration) == overlay['before_sha256'] and sha(fixed_migration) == overlay['after_sha256']
        assert_config_only(old_migration, fixed_migration)
        methods = []
        for entry in manifest['files']:
            name = entry['path']
            old = (old_base / name).read_bytes() if entry['baseline_exists'] else None
            assert (sha(old) if old is not None else None) == entry['before_sha256']
            feature = source_entry(manifest, entry)
            actual = current.get(name, ('file', None))[1]
            if name in MIRRORS:
                assert feature.startswith(old) and feature.count(old_migration) == 1
                suffix = feature[len(old):]
                assert suffix.count(old_migration) == 1
                result = actual + suffix.replace(old_migration, fixed_migration)
                assert result.startswith(actual) and result.count(fixed_migration) == 1
                method = 'exact_NEW_prefix_plus_fixed_next_migration_once'
            elif name == migration_path:
                result, method = fixed_migration, 'reviewed_config_only_next_migration'
            elif name == TYPE_PATH:
                assert actual == layout(old), 'Unexpected type change outside known root Row layout'
                result, method = layout(feature), 'only_reviewed_Row_layout_on_exact_feature_types'
                methods.append({'path': name, 'typeLayoutProof': prove_type_layout(feature, result)})
            elif phase == '0060' and name == 'src/components/SpinClient.tsx':
                common = next(row for row in ui['files'] if row['path'] == name)
                assert sha(old) == common['before_sha256'] and ('file', actual) == approved_parent_common[name]
                result, method = feature, 'exact_thin_wrapper_with_explicit_F6_controller_mapping'
            elif name == 'src/components/fan/FanGameController.tsx':
                row = mapped['files'][0]
                assert sha(feature) == row['before_sha256']
                result, method = approved_controller, 'reviewed_F6_then_exact_privacy_then_context_only_animation_mapping'
            elif name == 'scripts/db/schema-drift-check.mjs':
                assert actual.count(CRYPTO_TAIL) == 1
                result, method = merge_text(actual.replace(CRYPTO_TAIL, b''), old, feature,
                                            phase + '/' + name, generation / 'conflicts')
                assert result.count(LOOP_END) == 1
                result = result.replace(LOOP_END, CRYPTO_TAIL + LOOP_END)
                assert b'    probeGrants(db);\n    probeOrgIsolation(db);' in result
                method = 'three_way_all_probes_plus_exact_common_crypto_probe_last'
            else:
                result, method = merge_text(actual, old, feature, phase + '/' + name, generation / 'conflicts')
            current[name] = ('file', result)
            methods.append({'path': name, 'method': method})
        if phase == '0060':
            current[WORKFLOW] = ('file', retired_workflow)
            methods.append({'path': WORKFLOW, 'method': 'retire_only_known_once0059_mutation_invocation'})
        if phase == '0061':
            row = fixture['files'][0]
            name = row['path']
            assert sha(current[name][1]) == row['before_sha256']
            current[name] = ('file', source_entry(fixture, row))
            methods.append({'path': name, 'method': 'reviewed_seeded_fixture_admission_budget_only'})
        for descriptor in approval.get('approvedPhaseExtraManifests', []):
            if descriptor['phase'] == phase:
                apply_reviewed_overlay(current, descriptor, methods)
        for name in before_new:
            if name.startswith('supabase/migrations/'):
                assert current[name] == before_new[name], f'Prior migration changed: {name}'
        source = generation / 'sources' / phase
        write_map(source, current)
        reports.append(freeze(generation / ('phase-' + phase), phase, before_new, current, source, prior_source,
                              AUTHORITIES[phase], {'root0059Commit': root_sha, 'composition': methods}))
        prior_source = source
    before_safety = dict(current)
    for entry in safety['entries']:
        name = entry['path']
        actual = current.get(name, ('file', None))[1]
        assert (sha(actual) if actual is not None else None) == entry['before_sha256']
        after = resolved(Path(safety['source']) / name).read_bytes()
        assert sha(after) == entry['sha256']
        current[name] = ('file', after)
    safe_source = generation / 'sources' / '0063-safe'
    write_map(safe_source, current)
    reports.append(freeze(generation / 'phase-0063-safety', '0063-safety', before_safety, current,
                          safe_source, prior_source, SAFETY_SHA, {'uniqueSafetyPaths': 7, 'root0059Commit': root_sha}))
    before_final = dict(current)
    for entry in final['entries']:
        name = entry['path']
        old = resolved(Path(final['baseline']) / name).read_bytes() if entry['before_sha256'] is not None else None
        assert (sha(old) if old is not None else None) == entry['before_sha256']
        feature = source_entry(final, entry)
        actual = current.get(name, ('file', None))[1]
        result, method = merge_text(actual, old, feature, 'final/' + name, generation / 'conflicts')
        current[name] = ('file', result)
    final_source = generation / 'sources' / 'final'
    write_map(final_source, current)
    reports.append(freeze(generation / 'phase-final', 'final', before_final, current, final_source, safe_source,
                          FINAL_SHA, {'root0059Commit': root_sha, 'baseline': 'NEW0063 plus safety7'}))
    for folder, expected_tree in immutable_sources.items():
        assert tree(file_map(resolved(Path(folder)))) == expected_tree, f'Immutable source changed: {folder}'
    assert archive_map(root_sha) == root_rows
    assert git('branch', '--show-current').decode().strip() == 'dashboard-redesign', 'Integration branch changed during isolated composition'
    result = {'root0059Commit': root_sha, 'rootTree': tree(root_rows),
              'rootCommonPathsSince964': sorted(name for name in set(root_rows) | set(original_root)
                                                if root_rows.get(name) != original_root.get(name)),
              'phases': reports, 'verification': 'Composition/reconstruction only; focused/full/hosted release verification pending',
              'immutableSourceTreesPreserved': immutable_sources,
              'live_or_hosted_writes': False}
    (generation / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


def configure(capsule, historical):
    global CAPSULE, ALIASES, MANIFESTS, FILE_ALIASES
    CAPSULE = capsule
    latest = HERE / 'authorities/leaderboard-withdrawal-privacy-repair-01'
    latest_manifest = latest / 'manifest.original.json'
    latest_rows = json.loads(latest_manifest.read_text())
    MANIFESTS[str(TASK / 'leaderboard-withdrawal-privacy-repair-01/manifest.json')] = latest_manifest
    for entry in latest_rows['files']:
        FILE_ALIASES[str(TASK / 'leaderboard-withdrawal-privacy-repair-01/source' / entry['path'])] = latest / 'source' / entry['path']
    index = json.loads((capsule / 'INDEX.json').read_text())
    aliases = json.loads((historical / 'reconstruction-report.json').read_text())['originalDirectoryAliases']
    ALIASES.update(aliases)
    for phase in index['phases']:
        if phase['phase'] in AUTHORITIES:
            MANIFESTS[str(TASK / ('phase-' + phase['phase'] + '-compatible-final/manifest.json'))] = capsule / phase['manifest']
        elif phase['phase'] == '0063-safety':
            MANIFESTS[str(TASK / 'final-hardening-compatible-02-release-safety-base.json')] = capsule / phase['manifest']
        elif phase['phase'] == 'final03':
            MANIFESTS[str(TASK / 'final-hardening-compatible-03-manifest.json')] = capsule / phase['manifest']
    for overlay in index['overlays']:
        original = json.loads((capsule / overlay['manifest']).read_text())
        MANIFESTS[str(TASK / overlay['authority'])] = capsule / overlay['manifest']
        for entry in overlay['entries']:
            # Standard manifests carry source on entry or parent; privacy's
            # immutable camelCase schema has separately named common/mapped dirs.
            if overlay['authority'] == 'ui-leaderboard-privacy-01/manifest.json':
                original_source = TASK / 'ui-leaderboard-privacy-01' / ('mapped-source' if entry['path'] == original['mapped']['path'] else 'common-source') / entry['path']
            else:
                original_source = Path(entry.get('source', str(Path(original['source']) / entry['path']))) if 'source' in original else Path(entry['source'])
            FILE_ALIASES[str(original_source)] = capsule / entry['portableSource']


def privacy_descriptors(output):
    original_path = resolved(TASK / 'ui-leaderboard-privacy-01/manifest.json')
    original = pinned(original_path, 'b476ee8e090957ecf425cc69fbd58b32bc3cc9f96423f3148c9275cb824c20c0')
    result = []
    for kind, entries in [('common', original['files']), ('mapped', [original['mapped']])]:
        rows = [{'path': row['path'], 'before_sha256': row['beforeSha256'],
                 'after_sha256': row['afterSha256']} for row in entries]
        normalized = {'source': str(TASK / 'ui-leaderboard-privacy-01' / (kind + '-source')),
                      'files': rows, 'derivedWithoutChangingOriginal': True,
                      'originalManifestSha256': sha(original_path.read_bytes()),
                      'schemaOnlyNormalization': 'camelCase hash keys to standard reviewed descriptor keys'}
        path = output / ('privacy-' + kind + '-descriptor.json')
        path.write_text(json.dumps(normalized, indent=2) + '\n')
        result.append({'manifest': str(path), 'sha256': sha(path.read_bytes())})
    return result


def main():
    global REPO, TEMP_ROOT, OUTPUT_ROOT, START_HEAD
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--capsule', required=True, type=Path, help='Extracted future-work-inputs directory')
    parser.add_argument('--root-sha', required=True)
    parser.add_argument('--output', required=True, type=Path, help='NEW directory outside repository')
    parser.add_argument('--write', action='store_true', help='Write new composed source outside checkout; no release actions')
    arguments = parser.parse_args()
    REPO = arguments.repo.resolve()
    output = arguments.output.resolve()
    assert len(arguments.root_sha) == 40 and all(char in '0123456789abcdef' for char in arguments.root_sha)
    assert not output.exists() and not output.is_relative_to(REPO) and not REPO.is_relative_to(output)
    assert git('branch', '--show-current').decode().strip() == 'dashboard-redesign'
    START_HEAD = git('rev-parse', 'HEAD').decode().strip()
    assert subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', arguments.root_sha, 'HEAD'], capture_output=True).returncode == 0
    if not arguments.write:
        print(json.dumps({'write': False, 'rootCommit': arguments.root_sha,
                          'next': 'Add --write for isolated source composition; no hosted or checkout mutation'}))
        return
    OUTPUT_ROOT = output
    output.mkdir(mode=0o700)
    TEMP_ROOT = output / "temporary"
    TEMP_ROOT.mkdir(mode=0o700)
    historical = output / 'historical'
    restore = subprocess.run(['python3', str(arguments.capsule.resolve() / 'restore_historical.py'),
                              '--repo', str(REPO), '--output', str(historical)], capture_output=True, text=True)
    assert restore.returncode == 0, restore.stderr
    configure(arguments.capsule.resolve(), historical)
    common, mapped = privacy_descriptors(output)
    approval = {'rootCommit': arguments.root_sha, 'rootReviewedCommonCrypto': True,
                'rootApprovedCryptoProbeOrdering': True, 'rootApprovedFutureCryptoManifest': CRYPTO_SHA,
                'approvedParentPrivacyManifests': [common], 'approvedMappedPrivacyManifests': [mapped],
                'provenance': 'Root task explicitly approved crypto config/probe ordering and final reviewed privacy+animation chain.'}
    (output / 'derived-input-descriptors.json').write_text(json.dumps(approval, indent=2) + '\n')
    reassemble(arguments.root_sha, output / 'composed', approval)


if __name__ == '__main__':
    main()
