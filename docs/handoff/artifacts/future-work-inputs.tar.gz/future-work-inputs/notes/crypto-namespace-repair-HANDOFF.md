# Crypto namespace0059 correction — frozen, local evidence only

## Exact source and application boundary

Baseline is root commit `6e830472b213874aeac1a40cd0bb3e1116de3c5e`.
Source: `crypto-namespace-repair-01/`.
Frozen10-path subset: `crypto-namespace-repair-frozen-delta/`.
Manifest: `crypto-namespace-repair-final-manifest.json`, SHA256
`8d6b499d05ae19015673bfb7ed93375c5dce09827c6fcdcb615fed8c45cec457`.
Context patch SHA256:
`618fd8ad694372949c2f61784d38000c79b0ff76bfb2752ae37dad4db6f4a32d`.
Complete1532-file source tree:
`14f650a54695c62c6ba1b3bc91ed481a426eba0472ecc408622a1bcbe2c5a827`.

The10 changed paths and entire source reconstruct exactly from the baseline.
No original path was deleted. All function bodies, argument/default/return
contracts, economic rules, seed derivation, grants, RLS and earlier migration
bytes are preserved. `db.types.ts` is unchanged. The Production migration job
and all existing workflow application/history/type steps remain byte-exact.
Only a TEST correction invocation is inserted after db push.

The immutable manifest was frozen while the final201-unit run was pending. Its
identity remains unchanged. `crypto-namespace-repair-final-checks.json` records
that run's later completed result and rechecks all final source hashes.
A separate during-finalization201-pass log is retained as earlier evidence,
not used to claim the final source remained frozen during that earlier run.

Root may copy/apply these10 reviewed files with before/after hash guards. The
root's parallel common history-UI fix is outside this source. Root still owns
two complete release rounds after composing both fixes, exact-SHA CI, actual
TEST correction/runtime results and Preview deployment. No Preview, hosted
project read/write, credential read, main/Production operation or email was
performed by this preparation. Only public official API documentation was fetched.

## Actual bug and chosen correction

`crypto-namespace-diagnosis-local.json` reproduces the hosted failure using
pgcrypto in `extensions`: the original0059 service grant fails with
`function digest(text, unknown) does not exist`. Its SECURITY DEFINER function
pins search_path to public. Anonymous/authenticated callers remain refused.

Exactly15 direct-crypto0059 functions now pin search_path to
`public,extensions,pg_temp`, in the migration and both complete SQL mirrors.
PostgreSQL implicitly searches pg_catalog first. Public and extensions remain
trusted schemas; API roles must not have CREATE there. pg_temp is explicitly
last. This retains both existing public pgcrypto and the hosted extensions
layout, without moving an extension or changing any hash/random-byte operation.
No function body or ACL is replaced by the actual TEST correction.

## One-time actual TEST correction

0059 is already recorded on TEST, so changing its checked-in definition alone
would not reexecute it. The new TEST workflow step runs
`node scripts/db/repair-test-crypto-0059.mjs` after normal db push and before the
existing real history/type checks. It uses the existing private
SUPABASE_ACCESS_TOKEN; the only project endpoint is fixed to
`https://api.supabase.com/v1/projects/snmcrmhgevfqggxdiomu/database/query`.

Before transport it requires the exact repository, pull_request event,
dashboard-redesign head, TEST ref, latest checked-in migration0059, corrected
migration SHA256 `c91468813552d75acdf783dfb0f17b73377afc9e9dc6c66dbcde28c69b7fe2e4`
and the immutable15-function manifest SHA256
`72e4599213e1705712af5c1865877b0a33b1667053412866f5c30b3affb6a2f7`.
No environment input becomes SQL or changes the destination.

The transaction reads actual migration history and extension catalog. It accepts
pgcrypto only in public/extensions, requires its exact digest(text,text),
digest(bytea,text) and gen_random_bytes(integer) extension members, and rejects
all other same-named public/extensions overloads, including default/variadic
shadow candidates. It checks all three API roles cannot CREATE in either schema.

Before the first ALTER, all15 exact procedure identities must have their
original body SHA, language, SECURITY DEFINER flag, postgres owner and either
the old or exact target configuration. Anonymous/authenticated EXECUTE must be
false for every function; service_role must be false for the five private cores
and true for the ten server gateways. Body hashing uses core
pg_catalog.sha256/convert_to, independently of the broken lookup.

The only persistent commands are explicit allowlisted ALTER FUNCTION SET
search_path commands. Already-target configurations are left alone. Before/after
full pg_proc metadata excluding only proconfig must match, preserving OID,
body, owner, ACL and every other attribute. All target configs are rechecked.
No table data, migration history, function body, owner or ACL is updated.

The advisory transaction lock coordinates this helper's invocations. It does
not serialize unrelated privileged administrator DDL or all other PRs. Root
must operate in the reviewed serialized TEST release window and recheck the
branch and actual metadata before Preview. The helper never needs catalog
UPDATE or SUPERUSER privileges. Native concurrent-definition tests prove a
changed body cannot receive a verified result and is never overwritten.

After the transaction, a separate provider-read_only single SELECT freshly
checks all15 definitions, effective API privileges, namespaces and target configs.
A mutation HTTP success alone does not produce a green result.

Official reference read: https://supabase.com/docs/reference/api/v1-run-a-query
(`crypto-management-query-official.html/.txt`). It documents success201 and an
unconstrained body schema. The helper strictly accepts201 plus empty JSON array
for its transaction acknowledgement, then201 plus the exact catalog row shape
for readback. This expected DO acknowledgement is locally faked, not yet observed
on the actual hosted endpoint. Any unexpected status/body or mutation timeout
returns `CRYPTO_REPAIR_OUTCOME_UNKNOWN_USE_READBACK`; no mutation is automatically
retried. An accepted mutation whose fresh readback fails returns
`CRYPTO_REPAIR_SUBMITTED_READBACK_UNVERIFIED`. Neither is called a completed
correction. Only fixed codes/counts/booleans are printed; raw API bodies and
credential values are suppressed.

`--read-only` performs just the catalog SELECT. Its JSON can honestly report
oldConfigFunctions15/configurationVerifiedfalse; a readback process exit0 means
observation succeeded, not that correction is verified. Where credentials are
available only in Actions, root must prepare a reviewed TEST-only command change
for that inspection rather than copying keys into the workspace/chat. Inspect
an ambiguous outcome before choosing another correction invocation.

## Required retirement WITH0060

After root verifies actual0059 correction and release, retire ONLY its workflow
invocation when integrating0060, before0060's full verification/push. Keep the
helper, immutable manifest, native fixture, pure tests and both active/retired
workflow test cases. The helper deliberately refuses source/history beyond0059.

`crypto-namespace-future-overlays/0060/retire-workflow-call.patch` removes exactly
SIX total lines, including two comments. SHA256:
`256de203852f99bc9ad459519b30b67c547a91274acb1b3ea14b6e31035b7635`.
Workflow before `ea70c805275aa749b868f0630f3c37286e15f2104b272470f6591b7b8a6c5052`,
after `3edf41ab3d21748260d71a06d3ce467bb52f8cecee48b3462957b4591863b649`.
The latter is the original unmodified workflow. These six lines include the
comments; the older frozen manifest's prose must not be read as removing eight.
`retirement.json` is the precise operational patch receipt.

## Genuine final local checks

All final source hashes were rechecked unchanged:

-201/201 full unit files pass on existing Next16.4.3 dependencies. New pure
  repair suite has46 assertions: source/project/branch/manifest guards before
  I/O, strict responses/readback, no credential SQL, no automatic mutation retry,
  independent provider read_only mode, active and retired invocation fixtures,
  and actual20-second outer bounds for uncooperative fetch and response bodies.
- Whole TypeScript/noEmit/incrementalfalse0; whole ESLint0; explicit ESLint on
  modified drift plus new MJS/helper/fixture/probe and TS suite0.
- Both complete PostgreSQL16 matrices pass: all five constructions in each
  layout. Extensions yields1340 public/storage catalog entries; public yields1376.
  The original catalog query is unchanged; the36 pgcrypto functions move outside
  its public/storage scope in hosted mode. All old probes remain, including
  272Focus and18reward-view cases perA/B/C, storage, admin, stock/credit races
  and old immediate probeGrants→probeOrgIsolation ordering. The new probe adds
  trusted crypto-config checks and six actual API-role CREATE refusals perA/B/C.
-76 separate actual native cases pass in both layouts under a real NOSUPERUSER
  function owner without catalog UPDATE. They cover the causal old extensions
  failure, preserved invalid-intent refusal after hash resolution, before/after
  API EXECUTE negatives, complete metadata/ACL equality, fresh readback,
  idempotent no-catalog-row rewrite, unsafe namespace permission, unexpected
  config/security/ACL/body/history and defaulted crypto-shadow refusals, and
  inter-session concurrent body replacement. Source transaction tests create
  no actual users/rewards and use only disposable local history fixtures.
-43 recursive e2e/scripts MJS parser checks pass.
-10/10 changed paths and the complete1532-file source reconstruct exactly.

Logs: crypto-namespace-all-unit.log/.exit; crypto-namespace-unit-focused.log/.exit;
crypto-namespace-final-{extensions,public,native}.log/.exit;
crypto-namespace-static-final.json; crypto-namespace-repair-final-checks.json.
Early fixture setup/type/lint/parser diagnostics remain separately saved. No
failed or incomplete run is counted as passing. The focused lint found an old
unused drift import and three old shortcut-expression warnings; the import was
removed and the identical conditional load sequences were written as if blocks.
The final matrices include that cleanup; no assertions or lint rules were removed.

No app build, browser, actual Management API acknowledgement, TEST correction,
hosted RLS or Preview proof is inferred from these local checks.

## Future numeric configuration overlays

`crypto-namespace-future-overlays/manifest.json` SHA256:
`3b0c64cc271da36d22d02e995dd4a65aad0659a46bf7f97bb106f1a7400e893c`.
Only migration-local config changes are supplied, preserving every body and
other SET timeout clause:0060 three definitions,0061 three,0062 five,0063 two.
Each folder includes exact old/new migration bytes and its reconstructing patch;
`reconstruction.json` confirms4/4. These are authorized copies, not edits to old
frozen sources. The numeric owner must inherit root's NEW clean0059 common source
(including the separately owned UI fix), retain its actual corrected SQL prefixes,
and append each fixed next migration exactly once to both mirrors. Never replace
a newer complete mirror with an older snapshot. Future full release checks remain
required; these migration-only overlays do not claim future matrix/unit passes.
