# Final3d hardening — final03 freeze, 2026-10-28

This supersedes final02 for future composition, without editing either old02
source, its baseline, its manifest or its genuine full245-file evidence.

## Exact identity

- Source `final-hardening-compatible-03/`,1661files/symlinks.
- Manifest `final-hardening-compatible-03-manifest.json` SHA256
  `29c968d6f0a95aa73a2c38a7b585e8665f7e1d1f2d31b2b68a2f439c60f7f177`.
- Full source tree
  `2235a7bdff744ced5be5ab01521458fc557b3b62aa32be4faad56f799c081cff`.
- Context patch `final-hardening-compatible-03-context.patch` SHA256
  `b4d17952a9fa74964671d95ec65ac918761fb1bf44fee0e2dad03d91d9314be2`.
- Exactly36changed paths and whole-source reconstruction are proven in
  `final-hardening-compatible-03-reconstruction.json`. Frozen changed bytes are
  `final-hardening-compatible-03-frozen-delta/`.

The explicit baseline is NEW0063 + reviewed release-safety7 + root's known hosted
Row-format correction. Baseline source is
`final-hardening-compatible-03-release-safety-base/`, tree
`0c7cfbbbb522dbe7c516d32420da0949981b9e954ec0a5d51260b4e78a8a678e`.
Receipt `final-hardening-compatible-03-baseline.json` SHA256
`176f52065c185f41986fc81d380311971084c93d0a002b2325371cf506dead0e`.
It links the previous numeric/safety authority and records the exact literal
before/after layout. The common Row correction is NOT part of the36-path delta.

## Changes from immutable final02

Root explicitly approved the four-path hosted-instant-smoke delta, manifest
`150e02b4d65d049e11e965e8cc5beb5313c5798ffe6f72cc6316cd939e62a9e4`.
Each of its four before/after hashes was checked while applying to the NEW copy.
It adds a bounded real-code roundtrip/stock/recovery/re-view/secrecy flow to the
existing future hosted smoke. This is prepared source, not a hosted execution.
Original-key owner backup, actual healthy0063deployment and fresh unlatch health
remain real prerequisites. No initialization, key read, anchor change or email
occurred. Read `hosted-instant-smoke-prep/HANDOFF.md` for the exact flow/boundaries.

Root commit `6e830472b213874aeac1a40cd0bb3e1116de3c5e` changes only the compact
`actor_request_cancellations.Row` declaration to the actual hosted generator's
multiline layout. That same exact literal replacement occurred ONCE in each NEW
base/final copy. Both future fulltype hashes change109bac3e...→1834880b...;
root0059's shorter file naturally has different whole-file hashes.
Complete ordered TypeScript ASTs match before/after, including13966nodes each;
see `final-hardening-compatible-03-layout-ast.json`. The original75database
contracts remain unchanged:74SQLfiles are raw-byte-exact, and db.types differs
from02 only in this proven layout. New03base/final types are byte-identical.

## Genuine final03 checks

-144focused guard assertions pass: original74plus70new.
- Explicit lint of both changed.mjs files and the changed test passes.
- Whole repository lint and whole TypeScript noEmit/incrementalfalse pass.
- All67recursive e2e/scripts.mjs syntax checks pass.
- Whole source hashes match before/after these checks.
- Repeating the exact reverse proof reconstructs the old complete smoke runner,
  every old journey/cleanup, all original74test assertions and old guards, with
  only stricter reward equality retained. See03preservation receipt.
- Both workflows/sharedPreviewguard, current literal-bracket runner, game recovery
  and journey acknowledgement are exactly unchanged from02.
- Context-patch check/apply reproduces all36changed paths and the complete1661file
  final03source; the explicit baseline is rechecked unchanged.

Final03 uses final02's unchanged431package installation READONLY, with identical
package/lock and actual tsx4.23.15/Next16.4.3 resolution verified. No fresh03install
is claimed. The full245/245unit run and scheduler49logic/53PG checks belong to
immutable02, before this additive4file/layout delta; they were NOT repeated on03.
Root's required two full release rounds remain pending.

## Root release gates remain

The complete scope and operational warnings in `final-hardening-phase02-HANDOFF.md`
still apply. Release0063 with safety7 before its first Preview; obtain actual
count evidence and follow genuine key/health/backup prerequisites. Apply this
final36delta with exact hashes; merge HANDOFF changes against any later actual
release-state updates instead of overwriting newer SHA/TEST/Preview facts.

No live checkout, Git commit/push, hosted request/mutation, real email, Production
operation, old Preview retirement, build or browser run occurred here. Root owns
both full rounds, actual exact-SHA CI/TEST/Preview clicks/smoke/performance,
scheduler activation+real completion, old-z100/new-z30 causal browser control,
two FRESH final auditors and remaining owner recovery/backup/phone checks.
