# Preserved future work: historical sources, not releases

This capsule preserves the exact prepared source for migrations 0060–0063 and the
small-fix hardening phase. None has reached TEST, Preview or production. It contains
only selected source, source patches, manifests and source handoff instructions.
Dependency folders, build output, Git objects, credential/environment files, reward
backups, provider metadata, browser screenshots, raw logs and private fan URLs are
excluded. The current repository handoff takes precedence over historical notes.

## Verify and reconstruct independently

From an extracted capsule (all commands are local and read-only toward Git):

```sh
python3 restore_historical.py --repo /absolute/path/to/fanfunnel --output /tmp/fanfunnel-preserved-sources --check-only
python3 restore_historical.py --repo /absolute/path/to/fanfunnel --output /tmp/fanfunnel-preserved-sources
```

The output directory must not exist and must be outside the repository. Keep the
capsule separate from the output. Git must contain historical commit
`9642dfd4d24518c201f736f93387443e43d80a8f` (already on `dashboard-redesign` history).
The builder verifies every capsule member, every historical before/after hash,
every complete source tree and every sequential patch. It writes source trees and
a directory-alias reconstruction report outside the checkout. It never installs,
starts a server, calls a hosted service, writes Git or deploys.

`INDEX.json` preserves the original absolute source paths as provenance and maps
those references to portable member names. The original manifest bytes/digests
are deliberately unchanged. The historical sequence is:

1. 0060 scratch: 94 paths, 1576 complete source files.
2. 0061 bingo: 81 paths, 1599 files.
3. 0062 account lifecycle/security: 67 paths, 1620 files.
4. 0063 operational crypto canary: 34 paths, 1639 files.
5. Required **0063 safety overlay: 7 unique paths**. Apply before the first 0063
   full verification, CI or Preview boot. It isolates startup health checks from
   CI secrets, scopes real integration credentials correctly and captures actual
   post-cleanup legacy counts. This is not permission to initialize a canary from
   synthetic proof or already-erased data.
6. The exact cancellation-Row **layout-only** correction from `6e830472...`.
7. Final hardening 03: 36 paths, 1661 files. This includes the declared/pinned
   development tool `tsx@4.23.15`, hosted smoke/performance/scheduler tooling,
   malformed-URL handling, bounded/hashed rate-limit storage and owner documents.

## Integrate deliberately onto repaired 0059

These historical patches MUST NOT simply replace current source. Their base
predates the hosted pgcrypto namespace repair, lazy delivery history, F6 read
admission, privacy withdrawal and animation fixes. Historical successful checks
inside immutable manifests apply only to the historical named source. New common
repairs and all required local/hosted checks remain necessary for each release.

`overlays/` preserves reviewed common and mapped source authorities: the 0059
crypto repair, future crypto configuration-only migration corrections, lazy
history, F6 read admission, Bingo fixture spacing and the transform-only animation
literal. The final reviewed privacy withdrawal common3/mapped1 authority is also included
(manifest b476ee8e090957ecf425cc69fbd58b32bc3cc9f96423f3148c9275cb824c20c0).
Map that exact reviewed correction into the future actual controller. Never overwrite the whole parent
from an older overlay. The animation literal must apply contextually after privacy.

For every numeric migration, preserve the complete repaired previous mirrors and
append only the exact corrected next migration once. Never copy an old whole
mirror. Preserve function bodies, grants, authorization, timeouts, every existing
negative test and all feature probes. Keep `probeGrants(db);` immediately followed
by `probeOrgIsolation(db);`; the common crypto probe may follow all numeric probes.
Carry the exact cancellation-Row layout and preserve the complete type contract.

0060 replaces legacy `SpinClient.tsx` with the exact thin wrapper. Map F6, privacy
withdrawal and the animation literal into `FanGameController.tsx`; do not copy a
newer game's complete controller into an earlier phase. 0060 also removes ONLY
the one-time 0059 hosted crypto-repair workflow invocation after actual 0059 repair
and its CI/Preview have succeeded. Keep the helper, manifest and tests. The exact
six-line retirement patch is preserved in `overlays/crypto-namespace-future-overlays/0060/`.
0061 adds the separately reviewed fixture spacing change outside its old 81 paths.

`prepared-composition/reassemble.py` is preserved UNMODIFIED as prepared work. It
has old environment-specific constants and awaits an exact clean repaired 0059
commit plus explicit reviewed input descriptors. Review and adapt its path resolver
using the reconstruction report before executing it. It is **not** a finished
portable integration command. `PLAN.md` explains the composition rules; current
handoff/root approvals supersede its historical “pending” wording.

After integration, require two complete verification rounds including both crypto
layouts, browser e2e then accessibility on the same fresh server, and all script
syntax. Push only `dashboard-redesign` after those pass, confirm exact-SHA CI,
actual TEST history/types/runtime/login, then deploy an exact-source Preview and
verify real clicks. Never push/merge `main` or write production Supabase.
