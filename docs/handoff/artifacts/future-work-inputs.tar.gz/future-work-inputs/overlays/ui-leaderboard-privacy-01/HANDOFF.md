# Leaderboard consent withdrawal repair

Frozen source-only common files: `common-source/` (three paths), plus `common.patch`.
The separate `mapped-source/` and `mapped.patch` change only the corresponding
future FanGameController parent. Do not replace an entire future controller from
a different numeric feature. `manifest.json` pins every before/after SHA256.

This preserves withdrawal at any time: F6 still hides the competitive leaderboard
and recent-wins ticker for blocked, paused or on-break fans, but an already opted-in
fan gets a neutral explicit removal control. The same control remains available
when the competitive public view is unavailable or switched off. It makes no
public read or automatic write, never joins or renames, sends only token and
`optIn:false`, suppresses duplicate submissions and requires HTTP success plus
literal `{ok:true}` before claiming removal. Failure remains retryable.

Existing regular join/switch uses the same private consent write and retains its
name validation/error behavior. Both regular and fallback successful withdrawal
refresh the existing route through its existing router. The board key includes fan
identity and authoritative consent, so a refreshed false initializes false while a
later deliberate rejoin remains available. Paid focus and earned history stay
readable during engagement breaks.

Validation actually run in isolated check-context:

- 72 actual component/parent/control lifecycle checks pass.
- Original byte-identical EngagementWidgets35, SpinClientRecovery38 and
  WinsGalleryHistory28 pass.
- Four causal controls fail as intended: hidden withdrawal, stale consent key,
  truthy success acceptance and duplicate write admission.
- Whole TypeScript and focused ESLint pass.
- Installed Next16 use-router reference was read before router.refresh use.

An initial diagnostic used the wrong recovery test location; its failure is kept
in recovery-existing.log. Corrected src/components/SpinClientRecovery.test.ts passes
in recovery-existing-corrected.log. No tests removed or weakened.

NOT a release receipt: no final combined full build, e2e/axe, hosted TEST mutation,
Preview deployment or full-two-round gate was performed here. Root must apply this
reviewed delta to the live common repair, then apply the separate transform-only
animation hunk by context, commit, and run the required complete verification twice
before pushing. No live checkout was edited by this worker.
