# Numeric common repair carry — preparation only

The live checkout and all existing frozen sources remain unchanged. New source
identities must start from the exact clean repaired0059 commit supplied by root.
No current source is claimed to be a release, full verification or hosted pass.

## Authorities

- Original0060: 94 paths, manifestc32bd32220c7e19f8a6ac8e12956c7503aae2361444b6944521c80551f82fe77.
- Original0061: 81 paths, manifestf53218839b1ab33ed26de422925d4aaf10d30d1fc609febe211edb4404081891.
- Original0062: 67 paths, manifest187fa36a0e370c8ed666f7d09e301fc28fc4c91018ace2424a4d303ddd7fe326.
- Original0063: 34 paths, manifestc2e61caa523a9e3690f827a8f35e77d7bfafa88ec3835f7144d3f1ab15bb8be7.
- Originalfinal03: 36 paths, manifest29c968d6f0a95aa73a2c38a7b585e8665f7e1d1f2d31b2b68a2f439c60f7f177.
- History2: db9433d47eb099b48224f487c429120480628b6e610e6daf68ac60ae4de5f6c7.
- F6common:1e683b91579fc3018e55004b7a960d80d705d9cce6006f718c9ed64d7a2341e3.
- F6controller:94ab7b621cf53a73d2bfdc49c99b825d042c379139f46e3fc3aae6d5a5700107.
-0061fixture:225f727367165de5ee0d3a47d97950b389ef5229fb529bdf562108b80d2b72d2.
- Futurecrypto migration configs:3b0c64cc271da36d22d02e995dd4a65aad0659a46bf7f97bb106f1a7400e893c.
- Commoncrypto0059 helper/probe/workflow source: awaiting final root-reviewed freeze.

## Reassembly

1. Extract root's exact new0059 Git archive outside every checkout; require the
   branch/HEAD/clean-tree assertion before extraction. Preserve symlinks and
   tracked source only; exclude dependency/build/Git output from identities.
2. Apply each original numeric authority against its actual new preceding phase.
   Validate every historical before/after hash first. Preserve inherited new
   common files, tests, helpers and fixes outside the feature delta.
3. Mirrors are never copied whole. Derive each frozen authority's exact append
   suffix from its previous mirror; substitute only its approved fixed next
   migration, then append that suffix to the complete new preceding mirror.
   Prove all earlier migration bytes and both complete prior prefixes survive.
4. Database types carry only the reviewed cancellation-Row layout. Require exact
   literal transformation of the approved type authority and complete AST equality;
   retain all feature type contracts and helper suffix without regeneration.
5.0060's exact thin SpinClient wrapper supersedes the legacy parent. Require its
   only new root-parent differences to be the approved two F6 conditions, then
   translate those conditions into the actual new FanGameController. All frozen
   controller bytes are identical before this two-condition mapping; never copy
   a newer game's whole controller into an earlier phase.
6. Merge drift changes by retaining the complete new bootstrap/import logic and
   every original feature probe. An exact two-line common CryptoNamespace probe
   collides with appended numeric probes. Detach those exact two lines, perform
   the otherwise clean three-way merge, and append those same lines once after
   all numeric probes. The original immediate Grants→OrgIsolation order stays.
   Read-only diagnostic evidence: drift-preflight-resolved.json (all four phases
   merge without conflicts); root approval for this ordering is pending.
7.0060 removes only the known one-time TEST crypto-repair invocation and its two
   comments. Keep the helper, manifest and every active/retired fixture assertion.
   This future retirement is not permission to release0060 before actual0059
   repair, CI and Preview gates succeed. Production job remains byte-identical.
8.0061 adds only the separately approved seeded-Bingo fixture spacing delta. Its
   games.mjs path is outside the original81, so expected count is82. Every
   behavior assertion, server quota and RNG/proof fixture is preserved.
9.0063 first gets an exact numeric34 identity, then the explicit seven-path
   startup/secret-scope/legacy-count overlay. Final hardening's36-path delta is
   relative to that new overlay baseline. Preserve newer root handoff facts by
   three-way merge rather than copying the old final handoff file wholesale.

## Checks before a new freeze

Prove exact changed-path and complete-tree reconstruction, immutable old sources,
new prior-mirror prefixes, only approved function-config changes with all SQL
bodies/ACLs/timeouts intact, all original probes and test assertions, literal type
layout/AST equality, wrapper/controller mapping and workflow retirement boundary.
Run focused changed behavior checks, whole types/lint and native syntax. Root owns
both full release rounds and actual exact-SHA CI/TEST/Preview gates for each phase.
